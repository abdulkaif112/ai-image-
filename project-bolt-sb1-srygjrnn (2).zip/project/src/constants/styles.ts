import { ImageStyle } from '../types';

export const IMAGE_STYLES: ImageStyle[] = [
  {
    id: 'realistic',
    name: 'Realistic',
    description: 'Photo-realistic images with natural lighting and textures',
  },
  {
    id: '3d',
    name: '3D Render',
    description: 'Computer-generated 3D models with detailed texturing',
  },
  {
    id: 'anime',
    name: 'Anime',
    description: 'Japanese animation style with vibrant colors',
  },
  {
    id: 'digital-art',
    name: 'Digital Art',
    description: 'Digital illustrations with bold colors and textures',
  },
  {
    id: 'oil-painting',
    name: 'Oil Painting',
    description: 'Classic oil painting style with rich textures',
  },
  {
    id: 'watercolor',
    name: 'Watercolor',
    description: 'Soft watercolor painting with flowing colors',
  },
  {
    id: 'neon',
    name: 'Neon',
    description: 'Vibrant neon-lit scenes with glowing elements',
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk',
    description: 'Futuristic urban scenes with high-tech elements',
  },
];

export const RANDOM_PROMPTS = [
  'A serene lake surrounded by autumn trees at sunset',
  'A futuristic city with flying cars and neon lights',
  'A magical forest with glowing mushrooms and fairies',
  'An underwater scene with colorful coral reefs and exotic fish',
  'A majestic dragon soaring through stormy clouds',
  'A cozy cabin in the mountains during winter',
  'A bustling alien marketplace on a distant planet',
  'A steampunk airship floating above Victorian London',
  'A peaceful Japanese garden with cherry blossoms',
  'A superhero battling a villain in a city skyline',
  'A mystical portal opening between two worlds',
  'A post-apocalyptic landscape with nature reclaiming the city',
  'A space station orbiting a beautiful nebula',
  'A robot companion helping a child with homework',
  'A fantasy castle on a floating island in the sky',
];