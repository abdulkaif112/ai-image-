import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ThemeProvider } from './context/ThemeContext';
import Header from './components/Header';
import ImageGeneratorForm from './components/ImageGeneratorForm';
import ImageGrid from './components/ImageGrid';
import EmptyState from './components/EmptyState';
import ParticleBackground from './components/ParticleBackground';
import { generateImage } from './utils/api';
import useLocalStorage from './hooks/useLocalStorage';
import { GeneratedImage, GeneratorFormData } from './types';
import './styles/animations.css';

function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [images, setImages] = useLocalStorage<GeneratedImage[]>('ai-generated-images', []);
  
  const handleGenerateImage = async (data: GeneratorFormData) => {
    try {
      setIsLoading(true);
      setError(null);
      
      const result = await generateImage({
        prompt: data.prompt,
        style: data.style,
        aspectRatio: data.aspectRatio,
      });
      
      if (result.success) {
        const newImage: GeneratedImage = {
          id: uuidv4(),
          url: result.url,
          prompt: data.prompt,
          style: data.style,
          timestamp: Date.now(),
          aspectRatio: data.aspectRatio,
        };
        
        setImages((prevImages) => [newImage, ...prevImages]);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      console.error('Error generating image:', error);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
        <Header />
        <ParticleBackground />
        
        <main className="container mx-auto px-4 pb-16">
          <ImageGeneratorForm 
            onSubmit={handleGenerateImage} 
            isLoading={isLoading} 
            error={error}
          />
          
          {images.length > 0 ? (
            <ImageGrid images={images} onRegenerate={handleGenerateImage} />
          ) : (
            <EmptyState />
          )}
        </main>
        
        <footer className="bg-gray-100 dark:bg-gray-800 py-6">
          <div className="container mx-auto px-4 text-center text-gray-600 dark:text-gray-400">
            <p>AI Image Generator - Transform your ideas into stunning visuals</p>
          </div>
        </footer>
      </div>
    </ThemeProvider>
  );
}

export default App;