interface GenerateImageParams {
  prompt: string;
  style?: string;
  aspectRatio?: string;
}

const API_KEY = '814be8db58a6f08ccfcfec0522fb3f3625aab7c70b10e491803f8f2597abf2f5a1bd34fc0f3eb22cd0f7eb8dee751770';
const API_URL = 'https://clipdrop-api.co/text-to-image/v1';

export const generateImage = async ({ prompt, style = 'realistic', aspectRatio = '1:1' }: GeneratorFormData) => {
  try {
    const formData = new FormData();
    formData.append('prompt', `${prompt} (${style} style, ${aspectRatio} aspect ratio)`);

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'x-api-key': API_KEY,
      },
      body: formData,
    });

    if (!response.ok) {
      const errorText = await response.text();
      if (response.status === 401) {
        throw new Error('Invalid or expired API key. Please check your credentials.');
      } else if (response.status === 429) {
        throw new Error('Rate limit exceeded. Please try again later.');
      } else {
        throw new Error(`API error (${response.status}): ${errorText || 'Unknown error occurred'}`);
      }
    }

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);

    return {
      success: true,
      url,
    };
  } catch (error) {
    console.error('Error generating image:', error);
    // Propagate the specific error message
    throw error instanceof Error ? error : new Error('An unexpected error occurred');
  }
};