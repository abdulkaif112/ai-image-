export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  timestamp: number;
  aspectRatio: string;
}

export type ImageStyle = {
  id: string;
  name: string;
  description: string;
};

export interface ThemeContextType {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export interface GeneratorFormData {
  prompt: string;
  style: string;
  aspectRatio: string;
}