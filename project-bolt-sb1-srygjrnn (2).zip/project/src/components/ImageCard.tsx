import React from 'react';
import { Download, RefreshCw } from 'lucide-react';
import Button from './ui/Button';
import { GeneratedImage } from '../types';

interface ImageCardProps {
  image: GeneratedImage;
  onRegenerate: (prompt: string, style: string, aspectRatio: string) => void;
}

const ImageCard: React.FC<ImageCardProps> = ({ image, onRegenerate }) => {
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = image.url;
    link.download = `ai-image-${image.id}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formattedDate = new Date(image.timestamp).toLocaleString();

  // Calculate aspect ratio class
  const getAspectRatioClass = (ratio: string) => {
    switch (ratio) {
      case '16:9':
        return 'aspect-[16/9]';
      case '9:16':
        return 'aspect-[9/16]';
      default:
        return 'aspect-square';
    }
  };

  return (
    <div className="group bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 border border-gray-100 dark:border-gray-700 h-full flex flex-col">
      <div className="relative overflow-hidden">
        <div className={`${getAspectRatioClass(image.aspectRatio)} bg-gray-100 dark:bg-gray-900 animate-pulse`}>
          <img
            src={image.url}
            alt={image.prompt}
            className="w-full h-full object-cover transform transition-all duration-500 opacity-0 animate-fade-in"
            onLoad={(e) => e.currentTarget.classList.remove('opacity-0')}
            loading="lazy"
          />
        </div>
      </div>
      
      <div className="p-4 flex-grow">
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
          {formattedDate}
        </p>
        <p className="text-gray-800 dark:text-gray-200 line-clamp-2 mb-2">
          {image.prompt}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">
          Style: {image.style}
        </p>
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">
          Aspect Ratio: {image.aspectRatio}
        </p>
      </div>

      <div className="p-4 pt-0 flex space-x-2">
        <Button 
          variant="outline"
          onClick={() => onRegenerate(image.prompt, image.style, image.aspectRatio)}
          className="flex-1 py-2 px-3"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Regenerate
        </Button>
        <Button 
          onClick={handleDownload}
          className="flex-1 py-2 px-3"
        >
          <Download className="w-4 h-4 mr-2" />
          Download
        </Button>
      </div>
    </div>
  );
};

export default ImageCard;