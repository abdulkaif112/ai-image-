import React from 'react';
import { Image } from 'lucide-react';

const EmptyState: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="bg-white/40 dark:bg-gray-800/40 backdrop-blur-sm rounded-xl p-8 text-center max-w-md mx-auto border border-gray-100 dark:border-gray-700">
        <div className="flex justify-center mb-4">
          <div className="bg-purple-100 dark:bg-purple-900/30 p-4 rounded-full">
            <Image className="h-12 w-12 text-purple-600 dark:text-purple-400" />
          </div>
        </div>
        <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">
          No images generated yet
        </h3>
        <p className="text-gray-600 dark:text-gray-300">
          Enter a description above and click "Generate Image" to create your first AI-generated image.
        </p>
      </div>
    </div>
  );
};

export default EmptyState;