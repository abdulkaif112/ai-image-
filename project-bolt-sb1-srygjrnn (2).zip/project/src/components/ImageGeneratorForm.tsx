import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import Button from './ui/Button';
import { IMAGE_STYLES, RANDOM_PROMPTS } from '../constants/styles';
import { GeneratorFormData } from '../types';

interface ImageGeneratorFormProps {
  onSubmit: (data: GeneratorFormData) => void;
  isLoading: boolean;
  error: string | null;
}

const ImageGeneratorForm: React.FC<ImageGeneratorFormProps> = ({ onSubmit, isLoading, error }) => {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState(IMAGE_STYLES[0].id);
  const [aspectRatio, setAspectRatio] = useState('1:1');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onSubmit({ prompt, style, aspectRatio });
    }
  };

  const handleSurpriseMe = () => {
    const randomIndex = Math.floor(Math.random() * RANDOM_PROMPTS.length);
    const randomPrompt = RANDOM_PROMPTS[randomIndex];
    setPrompt(randomPrompt);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg rounded-xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Describe the image you want
            </label>
            <div className="relative">
              <textarea
                id="prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A serene lake surrounded by autumn trees at sunset..."
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition duration-200 min-h-[100px]"
                required
              />
              <button
                type="button"
                onClick={handleSurpriseMe}
                className="absolute right-3 bottom-3 text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-300 flex items-center text-sm font-medium"
              >
                <Sparkles className="w-4 h-4 mr-1" />
                Surprise Me
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="style" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Select a style
              </label>
              <select
                id="style"
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none bg-no-repeat transition duration-200"
                style={{ backgroundPosition: 'right 0.5rem center', backgroundSize: '1.5em 1.5em' }}
              >
                {IMAGE_STYLES.map((styleOption) => (
                  <option key={styleOption.id} value={styleOption.id}>
                    {styleOption.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="aspectRatio" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Aspect Ratio
              </label>
              <select
                id="aspectRatio"
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent dark:bg-gray-700 dark:text-white appearance-none bg-no-repeat transition duration-200"
              >
                <option value="1:1">Square (1:1)</option>
                <option value="16:9">Landscape (16:9)</option>
                <option value="9:16">Portrait (9:16)</option>
              </select>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <p className="text-red-600 dark:text-red-400 text-sm">{error}</p>
            </div>
          )}

          <div className="flex justify-center">
            <Button
              type="submit"
              isLoading={isLoading}
              disabled={isLoading || !prompt.trim()}
              className="py-4 px-8 text-lg"
            >
              {isLoading ? 'Generating...' : 'Generate Image'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ImageGeneratorForm;