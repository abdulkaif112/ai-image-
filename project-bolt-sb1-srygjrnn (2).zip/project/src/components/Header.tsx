import React from 'react';
import { Sparkles } from 'lucide-react';
import ThemeToggle from './ui/ThemeToggle';

const Header: React.FC = () => {
  return (
    <header className="relative overflow-hidden bg-gradient-to-r from-purple-700 to-pink-600 dark:from-purple-900 dark:to-pink-800">
      <div className="absolute inset-0" id="particles-container">
        {/* Particle animation will be injected here via useEffect */}
      </div>
      <div className="container mx-auto px-4 py-6 relative z-10">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Sparkles className="h-8 w-8 text-white mr-2" />
            <h1 className="text-2xl font-bold text-white">AI Image Generator</h1>
          </div>
          <ThemeToggle />
        </div>
        <div className="mt-8 mb-12 max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Transform Your Ideas Into Stunning Images
          </h2>
          <p className="text-lg text-white/80">
            Create beautiful AI-generated art with a simple description.
            Choose from multiple styles and unleash your creativity.
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header;